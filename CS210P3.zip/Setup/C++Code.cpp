/*
NAME: John Brungard
CLASS: CS210
DATE: 6/11/2022
PURPOSE: This program displays grocery store items with their frequencies while adding a Histogram option.
*/

#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <string>
#include <iomanip>
#include <stdlib.h>
#include <fstream>
#include <vector>


using namespace std;

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("PythonCode");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}

/* Displays a menu so the user is aware of their choices and the program's capability */
void printMenu() {
	/* 
	All colors for reference: (NOTE: CHAR 1 PORTRAYS BACKGROUND COLOR AND CHAR 2 PORTRAYS LETTER COLOR.)
	1	Blue	9	Light Blue
	2	Green	0	Black
	3	Aqua	A	Light Green
	4	Red		B	Light Aqua
	5	Purple	C	Light Red
	6	Yellow	D	Light Purple
	7	White	E	Light Yellow
	8	Gray	F	Bright White
	*/
	system("Color F2");
	cout << setfill(' ') << setw(39) << "" << "CORNER GROCER ITEM-TRACKING" << endl;
	cout << setfill('=') << setw(105) << "" << endl;
	cout << "| 1. Show all items purchased and the number of times each item was purchased." << setfill(' ') << setw(26) << "" << right << '|' << endl;
	cout << "| 2. Show a number representing how many a times a specific item was purchased." << setw(25) << "" << right << '|' << endl;
	cout << "| 3. Show a Text-Based Histogram of all items purchased and the number of times each item was purchased." <<  '|' << endl;
	cout << "| 4. Exit" << setw(95) << "" << right << '|' << endl;
	cout << "| Enter your desired option as a number. Example: 1"  << setw(53) << "" << right << '|' << endl;
	cout << setfill('=') << setw(105) << "" << endl;
}

/* Gets input from the user to navigate through the menu and select the correct action.*/
void menuAction() {
	int choice;
	string item;

	try {
		do {
			printMenu();
			cin >> choice;

			// Catches an input mismatch.
			while (cin.fail()) {
				cin.clear();
				cin.ignore(256, '\n');
			}

			// Exits the program.
			if (choice == 4) {
				exit;
			}
			// Prints a list of all items with their frequencies (no repeats).
			else if (choice == 1) {
				CallProcedure("menu_option_1");
			}
			// Shows the user the frequency of an item a user inputs.
			else if (choice == 2) {
				cout << "Please enter the name of the item in plural form that you would like to see the frequency of." << endl;
				cout << "NOTE: Enter the item as just one word. Example: Cranberries" << endl;
				cin >> item;
				cout << item << " has a frequency of: " << callIntFunc("menu_option_2", item) << endl << endl;
			}
			// Writes to another file and displays a histogram of menu_option_1 to the user.
			else if (choice == 3) {
				// Used to use input file contents
				ifstream inFS;
				// Stores the file of frequency.dat into a vector
				vector<string> histogram{};
				// Stores the item names in the vector Histogram.
				string itemName = "NoName";
				// Stores the item frequencies in the vector Histogram
				int itemCount = -1;
				// Used in conjunction with Histogram vector to read the file contents.
				string line = "NoName";
				// Used to parse the Histogram Vector.
				string delimiter = " ";
				size_t pos = 0;

				// Writes frequency.dat for use in C++.
				cout << callIntFunc("menu_option_3", "*") << endl << endl;

				// Opens the file.
				inFS.open("frequency.dat");

				// Open error check.
				if (!inFS.is_open()) {
					cout << "The following file did not open: frequency.dat" << endl;
				}

				// Stores the input file in the Histogram vector.
				while (!inFS.eof()) {				
					if (!inFS.fail()) {
						getline(inFS, line);
						histogram.push_back(line);
					}
					else {
						cout << "The file frequency.dat has failed." << endl << endl;
					}
				}
				// File is no longer needed, so it is closed.
				inFS.close();

				cout << "Histogram" << endl;
				cout << "_________" << endl;
				// Prints the Histogram for the given input file.
				for (unsigned int i = 0; i < histogram.size() - 1; i++) {
					while ((pos = histogram.at(i).find(delimiter)) != string::npos) {
						// Example: if histogram.at(i) = Apples 4, itemName = [Apples]
						itemName = histogram.at(i).substr(0, pos);
						// Example: if histogram.at(i) = Apples 4, itemCount = [4]
						itemCount =  stoi(histogram.at(i).substr(pos + 1));
						// Clears the current string to npos so the loop can exit successfully.
						histogram.at(i).erase(0, pos + delimiter.length());
					}
					// Prints the Histogram while converting itemCount to its respective number of asterisks.
					cout << itemName << string(itemCount, '*') << endl;
				}				
			}
			// Error message.
			else {
				cout << "Error. Please enter any number 1-4 to validate an option." << endl << endl;
			}
		} while (choice != 4);
	}
	// Catch used because required. Try block and while loop does all the corrections to input.
	catch (...) {
	}
}

int main() {
	// Only menuAction() needs called for the program to run successfully.
	menuAction();

	return 0;
}