import re
import string


def menu_option_1():
    print()

    # Opens the provided input file for reading.
    input_file = open("CS210_Project_Three_Input_File.txt")
    # Splits each grocery item from one another in the file.
    items = input_file.read().split()
    # Sorts the items in alphabetical order while also eliminating duplicate items.
    specific_item = sorted(set(items))

    # Prints the name of the item along with its frequency.
    for item in specific_item:
        print(item + ":", items.count(item))
    
    # Closes the file immediately after use.
    input_file.close()

    print()
    

def menu_option_2(v):
    print()

    input_file = open("CS210_Project_Three_Input_File.txt")
    items = input_file.read().split()
    specific_item = sorted(set(items))
    
    # Initialize the count of how many times an item appears in an input file.
    item_count = 0
    # Turns user input to all lowercase if not already, to increase item frequency accuracy.
    user_item = v.lower()

    for item in items:
        # If the user's input item matches an item on the list:
        if item.lower() == user_item:
            # The count of the item's frequency increases by 1.
            item_count+=1
    
    input_file.close()

    # Returns the total number of times the user's input item matched an item on the list.
    return item_count    

 
def menu_option_3(v):
    print()

    input_file = open("CS210_Project_Three_Input_File.txt")
    items = input_file.read().split() 
    specific_item = sorted(set(items))

    # Opens frequency.dat for writing.
    histogram_data = open("frequency.dat", "w")

    # Writes the name of each item on the list (no repeats) along with their frequencies.
    for item in specific_item:
        histogram_data.write(item)
        histogram_data.write(" ")
        histogram_data.write(str(items.count(item)))
        histogram_data.write("\n")
    
    # Closes all files immediately after use.
    input_file.close()
    histogram_data.close()

    # Gives user knowledge on the total purhcases involved in the Histogram for reference.
    print("Total number of purchases displayed on Histogram:", end = ' ')
    item_count = len(items)
    return item_count
